
# Flipkart Clone Website

This repository contains a Flipkart clone website built using plain HTML and CSS. The purpose of this project is to recreate the basic functionality and design of the popular e-commerce website Flipkart.

# Installation
To run this Flipkart clone website locally, follow these steps:

Clone the repository:
git clone https://github.com/SounakDutta10/Flipkart-clone-using-HTML-CSS-

Navigate to the project directory: cd Flipkart-clone

Open the index.html file in your preferred web browser.

# Screenshot
![Logo](SC.png)

# Disclaimer
This project is a clone of the Flipkart website created for learning purposes. It is not affiliated with or endorsed by Flipkart in any way. The use of the Flipkart name and branding is purely for illustrative purposes.

Please note that this project is not intended for production use and may lack certain security features and optimizations found in the original Flipkart website.
